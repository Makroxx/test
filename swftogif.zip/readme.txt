Aleo SWF GIF Converter

Aleo SWF GIF Converter is an easy and fast way to batch convert SWF to GIF and GIF to SWF.

Copyright(C) 2002-2010 Aleo Software, Inc. All Rights Reserved

            Index
=============================
       1. Key Features
       2. How to Order
       3. Installation
       4. Requirements
       5. Version Info
       6. Contact Info
       7. Copyright(C)
=============================

Content
=======================================================================

1. Key Features

  SWF to GIF Converter

    * Convert Flash SWF to animated GIF
    * Convert to JPEG, PNG or GIF image series.
    * Two kinds of conversion modes: real time playing and frame by frame.
    * Set loop times of GIF.

  GIF to SWF Converter

    * Add web link
    * Add customizable preloader
    * Customize JPEG quality
    * Add background music
    * Generate HTML file
    * Set loop times of Flash SWF

2. How to Order

 For different kinds of users, we offer two license types: Personal License and Commercial License. 
 For more details, please goto the order page: http://www.aleosoft.com/order.html

3. Installation
 Step1: Download the zip archive(swftogif.zip) from http://www.aleosoft.com/download.html, then open the file with your usual archive program, WinZip for example. 
 Step2: Launch setup.exe by double-clicking, then follow the on-screen instructions.

4. Requirements

 OS: Microsoft Windows 98/98SE/Me, Microsoft Windows NT 4.0, Microsoft Windows 2000, 2003, Microsoft Windows XP, Microsoft Windows Vista, Microsoft Windows 7
 Adobe Flash Player Version 8 or above
 Hard disk free space: 10MB;

5. Version Info

 Title: Aleo SWF GIF Converter
 Version: 1.6
 Release Date: July 15th, 2010
 Produced by: Aleo Software Inc. 

6. Contact Info

 Web Site: http://www.aleosoft.com/swftogifconverter/index.html
 Technical support: support@aleosoft.com
 Sales support: sales@aleosoft.com
 Other: webmaster@aleosoft.com

7. Copyright(C)

Copyright(C) 2002-2010 Aleo Software, Inc. All Rights Reserved.