=== Admin Notebook ===
Tags: Notebook, Sticky Note, Admin Notebook
Requires at least: 4.7
Tested up to: 4.9
Stable tag: 3.3.3
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Admin Notebook is simply allow wordpress site admin to add notes.

== Description ==

Admin Notebook is simply allow wordpress site admin to add notes.